# Home Assistant Notes

- Integrations, automations, and VLAN/IOT-related considerations go here.
