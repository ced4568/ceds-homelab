# TrueNAS Datasets

- List ZFS pools, datasets, and what they are used for.
