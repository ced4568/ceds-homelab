# Proxmox Notes

- Document storage configuration, node names, and cluster plans here.
