# Monitoring Notes

- Describe Prometheus targets, exporters, and Grafana dashboards here.
