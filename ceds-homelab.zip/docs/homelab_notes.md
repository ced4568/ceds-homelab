# Homelab Notes

Freeform scratchpad for commands, quick fixes, and ideas.

- TODO: add commonly used Proxmox, K3s, and TrueNAS commands here.
